@extends ('layouts.master')


@section ('content')

  <style type="text/css">

.hrr{
margin-top: 0.2rem;
margin-bottom: 0.2rem;
border: 0;
border-top-color: currentcolor;
border-top-style: none;
border-top-width: 0px;
border-top: 1px solid rgba(255,255,255);
}

.hrr {
-webkit-box-sizing: content-box;
box-sizing: content-box;
height: 0;
overflow: visible;
}

.vl {
  border-left: 3px solid green;
  height: 500px;
}

</style>
  
  <?php $note="activve" ;?>
    <div class="app">
      <div class="app-body">
      <!--SIDEBAR -->
      @include('layouts.sidebarS')
      <!--END SIDEBAR -->

      <div class="app-content">

      <!--NAVBAR -->
      @include('layouts.navbar')
      <!--END NAVBAR -->


        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item " aria-current="page"> <a href="/student">Accueil</a> </li>
            <li class="breadcrumb-item active" aria-current="page">Notes et Moyennes</li>
          </ol>
        </nav>

      <div class="container-fluid"> <!-- container-fluid-->

      <h3 class="text-center">SEMESTRE EN COURS</h3>

  <div class="accordion" id="accordionExample">
    <div class="card " style="background-color: #0b06cc45 !important;">
      <div class="card-header bg-secondary " id="headingOne">
        <h2 class=" text-center mb-0">
          <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          {{$semester->label}} / {{$student->classroom->name}}
          </button>
        </h2>
      </div>

              <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
      
      <div class="table-responsive">
          <div class="card-body">
            <table class="table ">
            <thead class="thead-dark">
              <tr>
                
                <th scope="col">MATIERE</th>
                <th scope="col">PROFESSEUR</th>
                <th scope="col">NOTES</th>
                <th scope="col">MOYENNE</th>
              </tr>
            </thead>
                <div class="text-center">
                  @foreach($epreuves as $epreuve)
                  <span class="@if($epreuve->id == 1) badge badge-primary ml-3 @elseif($epreuve->id == 2) badge badge-success @else badge badge-dark @endif" style="font-size: 20px">{{$epreuve->name}}</span>
                  @endforeach
                </div>
            <tbody>
              @foreach ($subjects as $subject)
              <tr> 
                <td>{{$subject->name}}</td>

                <td>{{$subject->teacher->name}} {{$subject->teacher->surname}}</td>
                <td>
                <?php 
                $tests= $subject->tests()->get(); 
                ?>

                @foreach ($tests as $test)
                  <?php   
                   // $j++;
                  ?>
                  @foreach ($marks->where('test_id',$test->id) as $mark )
                  <span class="@if($test->type == 1 AND $mark->value==!null ) badge badge-primary @elseif($test->type == 2 AND $mark->value==!null) badge badge-success @elseif($test->type == 3 AND $mark->value==!null) badge badge-dark @else badge badge-danger  @endif ml-1 " style="font-size: 20px;" >
                    {{$test->testNum}} <hr class="hrr">@if($mark->value==null) N @else{{$mark->value}}@endif 
                  </span>
                    <?php 
                    //$Smark=$Smark + $mark->value;  
                   // $j++;
                    ?>
                  @endforeach
                @endforeach
               </td>

                <td></td>
              </tr>
              @endforeach
            </tbody>
          </table>

                  <!-- NOTE TOGGLE -->
                  <p>
                    <a class="btn btn-dark" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                      MOYENNE DU {{$semester->label}}
                    </a>
                  </p>

              <div class="collapse" id="collapseExample">
                <div class="row">
                  <div class="col-sm-6">
                    <div class="card card-body bg-dark" style="color:white;">
                      <h3 class="text-center">MOYENNE DU {{$semester->label}}</h3>
                      <h1 class="text-center">Pas encore disponible</h1>
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="card card-body bg-dark" style="color:white;">
                      <h3 class="text-center">RANG DU {{$semester->label}}</h3>
                      <h1 class="text-center">Pas encore disponible</h1>
                    </div>
                  </div>
                </div>

              </div> 
                  <!-- NOTE TOGGLE -->

                </div>
              </div>

              </div>
            </div>


           

          </div>

        <hr>
<!--
<h3 class="text-center">SEMESTRES CONCLUS</h3> -->
              @if (empty($academicyearsD))
                <h2 class=" text-center mb-0">
                  <button class="btn btn-danger" type="button" >
                   AUCUN SEMESTRE CONCLU
                  </button>
                </h2>
              @endif

        <!-- SECOND ROW -->
        <div class="row">

 <!-- START ACADEMIC YEAR DONE -->
            @forelse ($academicyearsD as $academicyearD) 
            <div class="card bg-primary">
              <div class="card-header bg-secondary " id="headingTwo">
                <h2 class=" text-center mb-0">
                  <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                  ANNEE SCOLAIRE 2019 - 2020 / SEMESTRE II / NIVEAU I
                  </button>
                </h2>
              </div>

              <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">

                <div class="card-body">
                
            <table class="table ">
            <thead class="thead-dark">
              <tr>
                
                <th scope="col">MATIERE</th>
                <th scope="col">TEACHER</th>
                <th scope="col">NOTES</th>
                <th scope="col">MOYENNE</th>
              </tr>
            </thead>
            <tbody>
              <tr> 
                <td>ANGLAIS</td>
                <td>M. OUATTARA OUSMANE</td>
                <td><span class="badge badge-primary ml-3" >15</span><span class="badge badge-primary ml-3" >15</span><span class="badge badge-primary ml-3" >15</span></td>
                <td><span class="badge badge-dark ml-3" >15</span></td>
              </tr>
              <tr>
                
                <td>MATHEMATIQUE</td>
                <td>M. BOSSINA HAMED</td>
                <td><span class="badge badge-primary ml-3" >15</span><span class="badge badge-primary ml-3" >15</span><span class="badge badge-primary ml-3" >15</span></td>
                <td><span class="badge badge-dark ml-3" >15</span></td>
              </tr>
              <tr>
                
                <td>SYSTEME D'EXPLOITATION</td>
                <td>M. KEITA MAMADOU</td>
                <td><span class="badge badge-primary ml-3" >15</span><span class="badge badge-primary ml-3" >15</span><span class="badge badge-primary ml-3" >15</span></td>
                <td><span class="badge badge-dark ml-3" >15</span></td>
              </tr>
              <tr> 
                <td>MERISE</td>
                <td>M. OUATTARA OUSMANE</td>
                <td><span class="badge badge-primary ml-3" >15</span><span class="badge badge-primary ml-3" >15</span><span class="badge badge-primary ml-3" >15</span></td>
                <td><span class="badge badge-dark ml-3" >15</span></td>
              </tr>
              <tr>
                
                <td>C++</td>
                <td>M. BOSSINA HAMED</td>
                <td><span class="badge badge-primary ml-3" >15</span><span class="badge badge-primary ml-3" >15</span><span class="badge badge-primary ml-3" >15</span></td>
                <td><span class="badge badge-dark ml-3" >15</span></td>
              </tr>
              <tr>
                
                <td>JAVA</td>
                <td>M. KEITA MAMADOU</td>
                <td><span class="badge badge-primary ml-3" >15</span><span class="badge badge-primary ml-3" >15</span><span class="badge badge-primary ml-3" >15</span></td>
                <td><span class="badge badge-dark ml-3" >15</span></td>
              </tr>
            </tbody>
          </table>

                  <!-- NOTE TOGGLE -->
                  <p>
                    <a class="btn btn-dark" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                      MOYENNE DU SEMESTRE II - 2019 / 2020
                    </a>
                  </p>
              <div class="collapse" id="collapseExample">
                <div class="row">
                  <div class="col-sm-6">
                    <div class="card card-body bg-dark" style="color:white;">
                      <h3 class="text-center">MOYENNE DU 1ER SEMESTRE</h3>
                      <h1 class="text-center">15</h1>
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="card card-body bg-dark" style="color:white;">
                      <h3 class="text-center">RANG DU 1ER SEMESTRE</h3>
                      <h1 class="text-center">3 EME</h1>
                    </div>
                  </div>
                </div>

              </div> 
                  <!-- NOTE TOGGLE -->

                </div>

              </div>
            </div>
            @empty



            @endforelse

            <!-- END ACADEMIC YEAR DONE -->

        </div>
        <!-- END SECOND ROW -->


      </div> <!-- END container-fluid -->


      </div>
    </div>
  </div>

<!-- CARD CAROUSEL JS 
<script type="text/javascript">

(function ($) {
  "use strict";
  // Auto-scroll
  $('#myCarousel').carousel({
    interval: 200
  });

  // Control buttons
  $('.next').click(function () {
    $('.carousel').carousel('next');
    return false;
  });
  $('.prev').click(function () {
    $('.carousel').carousel('prev');
    return false;
  });

  // On carousel scroll
  $("#myCarousel").on("slide.bs.carousel", function (e) {
    var $e = $(e.relatedTarget);
    var idx = $e.index();
    var itemsPerSlide = 3;
    var totalItems = $(".carousel-item").length;
    if (idx >= totalItems - (itemsPerSlide - 1)) {
      var it = itemsPerSlide -
          (totalItems - idx);
      for (var i = 0; i < it; i++) {
        // append slides to end 
        if (e.direction == "left") {
          $(
            ".carousel-item").eq(i).appendTo(".carousel-inner");
        } else {
          $(".carousel-item").eq(0).appendTo(".carousel-inner");
        }
      }
    }
  });
})
(jQuery);

</script>  -->

@endsection
